class Bread {
  final String name;
  final String price;
  final String imagepath;

  Bread({
    required this.name,
    required this.price,
    required this.imagepath,
  }
      );
}