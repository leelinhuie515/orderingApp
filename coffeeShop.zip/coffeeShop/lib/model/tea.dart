class Tea{
  String name;
  String price;
  String imagepath;

  Tea({
    required this.name,
    required this.price,
    required this.imagepath,
  }
      );
}